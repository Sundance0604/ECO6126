# Figures

`figure1_mechanism_design.png` presents the three mechanism outcomes separately
from the collapse and survival equations.

An SVG version is included for editing. Regenerate the figure with:

```bash
python code/mechanism_welfare_analysis.py
```

