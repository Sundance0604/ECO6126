# 7 Mechanism and Welfare Analysis

This section examines how expulsion changes the composition of market activity
and the social value created by that activity. The mechanism evidence is
organized around three post-treatment outcomes: fraudulent transactions,
honest-to-cheater conversion, and cooperative transactions. The welfare analysis
then aggregates the social net benefit of individual transactions over a fixed
observation window. Mechanism outcomes and welfare are both consequences of the
institutional switch. They are not treated as controls in the collapse equation.

## 7.1 Mechanism outcomes

Let `D_i` denote the expulsion switch for market run `i`, with `D_i = 1` when
expulsion is enabled and `D_i = 0` when it is disabled. Let `X_i` contain the
predetermined experimental controls and seed-level blocking variables. We
estimate three separate reduced-form equations:

$$
Fraud_{iT} = \alpha_F + \beta_F D_i + \gamma_F' X_i + \varepsilon_{Fi},
$$

$$
Conversion_{iT} = \alpha_C + \beta_C D_i + \gamma_C' X_i + \varepsilon_{Ci},
$$

$$
Cooperation_{iT} = \alpha_K + \beta_K D_i + \gamma_K' X_i + \varepsilon_{Ki}.
$$

`Fraud` is the number of honest-cheater transactions over the observation
window. `Conversion` is the share of initially honest agents who become
cheaters. `Cooperation` is the number of honest-honest transactions. When the
ledger contains transaction values, the analysis also reports cooperation
volume, defined as the sum of traded value in honest-honest transactions.

The protection-of-cooperation mechanism predicts `beta_F < 0`,
`beta_C < 0`, and `beta_K > 0`. Expulsion should reduce the number of
fraudulent encounters, reduce the conversion share, and preserve cooperative
exchange. The three coefficients are estimated separately because all three
outcomes are measured after treatment. A joint pattern in the expected
directions supports the mechanism narrative, but it is not a causal mediation
decomposition.

![Figure 7.1 Mechanism outcomes and their separation from collapse](../figures/figure1_mechanism_design.png)

**Table 7.1 Mechanism outcome regressions**

| Outcome | Definition | Expected sign | Treatment estimate | Cluster SE | 95% CI |
| --- | --- | --- | ---: | ---: | --- |
| Fraud | H-C transaction count | Negative | Pending event-level data | Pending | Pending |
| Conversion | Converted honest / initial honest | Negative | Pending event-level data | Pending | Pending |
| Cooperation | H-H transaction count | Positive | Pending event-level data | Pending | Pending |
| Cooperation volume | H-H traded value | Positive | Pending event-level data | Pending | Pending |

Notes: each row is a separate regression of the post-treatment outcome on the
expulsion switch and predetermined controls. Standard errors are clustered on
the random seed. Mechanism outcomes are not entered as controls in the market
collapse or survival equation.

## 7.2 Transaction social net benefit

For a transaction between agents `i` and `j`, let `g_ij^i` be the payoff to
agent `i` and `g_ij^j` the payoff to agent `j`. The social net benefit of the
transaction is

$$
S_{ij} = g_{ij}^{i} + g_{ij}^{j}.
$$

The model assigns a different social value to each transaction type:

| Transaction type | Social net benefit | Economic meaning |
| --- | ---: | --- |
| H-H cooperation | `2 g_HH > 0` | Mutually beneficial exchange |
| C-C cheating | `2 g_CC < 0` | Mutually destructive exchange |
| H-C fraud | `g_HC^H + g_HC^C` | Can be zero when fraud is a pure transfer |

The H-C expression is kept as a sum rather than assigned a positive value by
default. If the cheater's gain equals the honest agent's loss and no real
resource is created or destroyed, the social net benefit is zero. A positive or
negative value must come from the payoff assumptions in the simulator.

For each market run, define cumulative transaction welfare over the fixed
observation window as

$$
W_T = \sum_{t=1}^{T} \sum_{(i,j) \in \mathcal{A}_t} S_{ij},
$$

where `A_t` is the set of transactions executed in period `t`. The fixed
horizon avoids comparing markets with different observation lengths. If the
simulation ends before `T`, the ledger must state whether unobserved periods are
censored, truncated, or assigned zero welfare.

**Table 7.2 Welfare and market outcomes**

| Outcome | Definition | Reporting role |
| --- | --- | --- |
| `WT` | Sum of `S_ij` across transactions from `t = 1` to `T` | Primary welfare outcome |
| Cooperative volume | Sum of H-H traded value | Market activity and cooperation intensity |
| End-period wealth | Total wealth at the fixed horizon | Distributional and survival consequence |
| Survival time | Periods before collapse or the horizon | Market persistence |
| Wealth exhaustion | Agents with wealth at or below zero | Financial failure |
| Other market exit | Exit without wealth exhaustion | Separate exit channel |

## 7.3 Survival cost and wealth exit

A per-period survival cost `c` requires an explicit interpretation. If `c`
represents a real resource used to keep the market operating, resource-adjusted
social welfare is

$$
W_T(c) = W_T - c \times \text{participant-periods}.
$$

If `c` is an accounting normalization or a bookkeeping transfer rather than a
real resource loss, it should not be subtracted from `WT`. The analysis reports
transaction welfare and resource-adjusted welfare as distinct outcomes. It never
applies a survival cost silently.

Market exit is also separated from wealth exhaustion. Wealth exhaustion occurs
when an agent's balance reaches zero. Other market exit can occur because of an
expulsion, a voluntary rule, or another non-bankruptcy mechanism. Survival time
measures how long the market remains active before the honest population falls
below the collapse threshold. These outcomes answer different questions and are
reported in separate columns.

## 7.4 Inference and interpretation

The main mechanism estimate is the OLS coefficient on `D_i` with predetermined
controls and market-type fixed effects. Standard errors are clustered on the
random seed so that repeated transactions and repeated rules within the same
seed are not treated as independent observations. The reported interval is a
conventional 95% confidence interval from the clustered covariance matrix.

The mechanism results must not be used to construct a causal claim by adding
`Fraud`, `Conversion`, and `Cooperation` to a regression of collapse or
survival on the treatment. Those variables are affected by the treatment and
may also share unobserved determinants with the outcome. Such a regression
estimates an associational decomposition conditional on post-treatment
variables. A causal mediation claim requires additional assumptions, a defined
intervention on the mediator, and an identification strategy for the mediator
and outcome paths.

The required substantive pattern is therefore reported as three reduced-form
results. Expulsion protects cooperation if it reduces fraud and conversion while
raising cooperative activity. The welfare ledger separately shows whether the
compositional change produces a higher cumulative social net benefit. The
survival analysis remains the market-level outcome and is reported alongside,
not inside, the mechanism regressions.

## 7.5 Reproducibility and data requirements

The repository accepts either a run-level outcome file or a transaction ledger.
The run-level file must contain `run_id`, `seed`, `rho`, `p`, `treatment`,
`fraud_count`, `conversion_share`, `cooperation_count`, `wt`,
`end_wealth_total`, and `survival_steps`. Optional columns identify cooperative
volume, bankruptcies, other exits, and active participant-periods.

The event-level file must contain transaction type and transaction social net
benefit, either directly or through payer and receiver payoff columns. The
analysis script aggregates the ledger into market-run outcomes, estimates the
three mechanism regressions, and reports welfare and survival in separate
tables. No mechanism or welfare coefficient is filled from the aggregate
survival file, which does not contain these variables.

