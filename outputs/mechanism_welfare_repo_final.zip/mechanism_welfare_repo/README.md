# Mechanism and Welfare Analysis for Expulsion

This repository structures Section 7 of the fraudulent-trading agent-based
model. It analyzes three mechanism outcomes separately:

- `Fraud`: the number of honest-cheater transactions;
- `Conversion`: the share of initially honest agents who become cheaters;
- `Cooperation`: the number of honest-honest transactions.

It also defines social welfare at the transaction and market-run levels. The
analysis keeps mechanism regressions separate from collapse and survival
regressions. Fraud, conversion, and cooperation occur after the institutional
switch, so adding them to a collapse equation does not by itself identify a
causal mediation effect.

## Repository structure

```text
.
├── figures/
│   ├── figure1_mechanism_design.png
│   └── figure1_mechanism_design.svg
├── report/
│   ├── report.md
│   └── report.docx
├── code/
│   ├── mechanism_welfare_analysis.py
│   ├── build_report_docx.py
│   └── requirements.txt
└── tables/
    ├── table1_mechanism_regression_template.csv
    ├── table2_welfare_outcome_template.csv
    ├── transaction_net_benefit_rules.csv
    └── event_log_schema.csv
```

## Expected run-level file

If the simulator already exports one row per market run, provide a CSV with
these columns:

| Column | Meaning |
| --- | --- |
| `run_id` | Market-run identifier |
| `seed` | Random seed, used for clustered inference |
| `rho` | Initial cheater share |
| `p` | Conversion threshold |
| `treatment` | Expulsion switch: 0 or 1 |
| `fraud_count` | Number of H-C transactions |
| `conversion_share` | Converted honest agents divided by initial honest agents |
| `cooperation_count` | Number of H-H transactions |
| `cooperation_volume` | Optional traded value or count-based cooperation volume |
| `wt` | Fixed-horizon cumulative social net benefit |
| `end_wealth_total` | Total wealth at the end of the observation window |
| `survival_steps` | Periods before collapse or the censoring horizon |
| `bankrupt_count` | Optional number of wealth-exhaustion exits |
| `market_exit_count` | Optional exits not caused by wealth exhaustion |

Run:

```bash
python -m pip install -r code/requirements.txt
python code/mechanism_welfare_analysis.py --runs path/to/run_outcomes.csv
python code/build_report_docx.py
```

The estimator uses OLS with seed-clustered standard errors. Controls and fixed
effects are specified explicitly:

```bash
python code/mechanism_welfare_analysis.py \
  --runs path/to/run_outcomes.csv \
  --fixed-effects rho,p
```

Use `--controls` only for predetermined covariates that are distinct from the
fixed effects.

## Expected event-level file

For a transaction ledger, use:

| Column | Meaning |
| --- | --- |
| `run_id`, `seed`, `rho`, `p`, `treatment` | Run metadata |
| `transaction_id` | Unique transaction identifier |
| `t` | Period |
| `transaction_type` | `HH`, `CC`, or `HC` |
| `amount` | Optional traded amount |
| `social_net_benefit` | Optional precomputed transaction social payoff |
| `payer_payoff`, `receiver_payoff` | Used to calculate net payoff when the direct value is absent |
| `converted_agent` | Optional unique identifier for each honest-to-cheater conversion |
| `initial_honest` | Initial honest-agent count |
| `end_wealth_total` | End-of-window wealth |
| `survival_steps` | Collapse time or censoring horizon |
| `active_agent_steps` | Optional participant-periods for survival-cost accounting |

Run:

```bash
python code/mechanism_welfare_analysis.py \
  --events path/to/transactions.csv \
  --controls rho,p \
  --fixed-effects rho,p
```

The script aggregates transactions into run-level outcomes and then estimates
the treatment coefficient for:

- fraud count;
- conversion share;
- cooperation count;
- cooperation volume;
- cumulative social net benefit `WT`;
- possibly resource-cost-adjusted welfare;
- total end wealth;
- survival time.

## Survival cost

The flag `--survival-cost c` adds an explicit per-period participant cost. The
cost is subtracted from welfare only when `--survival-cost-is-resource` is also
supplied. Without that flag, the cost is reported separately and is not added
to `WT`. This prevents an accounting normalization from being presented as a
real resource loss.

Market exit and wealth exhaustion are also kept separate:

- `bankrupt_count`: wealth falls to zero;
- `market_exit_count`: exit for other reasons;
- `survival_steps`: market-level duration before the honest population falls
  below the collapse threshold or reaches the censoring horizon.

## No fabricated mechanism results

The supplied aggregate survival file does not contain transaction counts,
conversion events, cooperative volume, or welfare. The repository therefore
contains reusable result templates and code, not invented estimates. When the
complete run-level or event-level file is placed in the repository and the
script is run, the tables are populated directly from it.

