#!/usr/bin/env python3
"""Mechanism and welfare analysis for the expulsion experiment.

The analysis keeps three objects separate:

1. Mechanism outcomes: fraud, conversion, and cooperation.
2. Welfare accounting: transaction-level social net benefit and WT.
3. Market outcomes: cooperation volume, end wealth, and survival time.

It accepts either a run-level outcomes file or a transaction ledger. No values
are imputed for missing mechanism or welfare fields.
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd
from PIL import Image, ImageDraw, ImageFont


ROOT = Path(__file__).resolve().parents[1]
FIGURES = ROOT / "figures"
TABLES = ROOT / "tables"

INK = (0, 0, 0)
WHITE = (255, 255, 255)

PRIMARY_OUTCOMES = [
    "fraud_count",
    "conversion_share",
    "cooperation_count",
]
SECONDARY_OUTCOMES = [
    "cooperation_volume",
    "wt",
    "wt_resource_net",
    "end_wealth_total",
    "survival_steps",
]
EXPECTED_SIGNS = {
    "fraud_count": "negative",
    "conversion_share": "negative",
    "cooperation_count": "positive",
    "cooperation_volume": "positive",
    "wt": "positive",
    "wt_resource_net": "positive if c is a true resource cost",
    "end_wealth_total": "positive",
    "survival_steps": "positive",
}


def _font(size: int, bold: bool = False):
    candidates = []
    if bold:
        candidates.extend(
            [
                Path(r"C:\Windows\Fonts\arialbd.ttf"),
                Path("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"),
            ]
        )
    else:
        candidates.extend(
            [
                Path(r"C:\Windows\Fonts\arial.ttf"),
                Path("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"),
            ]
        )
    for candidate in candidates:
        if candidate.exists():
            return ImageFont.truetype(str(candidate), size=size)
    return ImageFont.load_default()


def _box(draw, bounds, fill, outline, radius=18):
    draw.rounded_rectangle(bounds, radius=radius, fill=fill, outline=outline, width=4)


def _arrow(draw, start, end, color=INK, width=5):
    draw.line((start, end), fill=color, width=width)
    x, y = end
    draw.polygon([(x, y), (x - 20, y - 10), (x - 20, y + 10)], fill=color)


def render_mechanism_figure(path: Path) -> None:
    width, height = 1800, 1050
    image = Image.new("RGB", (width, height), WHITE)
    draw = ImageDraw.Draw(image)
    draw.text((90, 55), "Mechanism outcomes are estimated separately", font=_font(48, True), fill=INK)
    draw.text(
        (90, 115),
        "The institutional switch changes three post-treatment channels",
        font=_font(30),
        fill=INK,
    )

    _box(draw, (90, 420, 350, 580), WHITE, INK)
    draw.text((220, 465), "Expulsion", font=_font(34, True), fill=INK, anchor="ma")
    draw.text((220, 510), "switch", font=_font(34, True), fill=INK, anchor="ma")
    draw.text((220, 550), "D = 0 or 1", font=_font(25), fill=INK, anchor="ma")

    channel_specs = [
        ("Fraud", "H-C transactions", "expected decrease", 230),
        ("Conversion", "honest-agent share", "expected decrease", 465),
        ("Cooperation", "H-H transactions", "expected increase", 700),
    ]
    boxes = []
    for label, subtitle, sign_text, top in channel_specs:
        _box(draw, (690, top, 1130, top + 135), WHITE, INK)
        draw.text((720, top + 28), label, font=_font(34, True), fill=INK)
        draw.text((720, top + 73), subtitle, font=_font(24), fill=INK)
        draw.text((720, top + 106), sign_text, font=_font(22), fill=INK)
        boxes.append((690, top, 1130, top + 135))

    # One shared vertical base keeps every arrowhead on an exact grid line.
    draw.line((400, 297, 400, 767), fill=INK, width=5)
    _arrow(draw, (350, 500), (400, 500), color=INK)
    for _, top, _, bottom in boxes:
        center_y = (top + bottom) / 2
        _arrow(draw, (400, center_y), (690, center_y), color=INK)

    draw.line((1270, 297, 1270, 767), fill=INK, width=5)
    for _, top, _, bottom in boxes:
        center_y = (top + bottom) / 2
        _arrow(draw, (1130, center_y), (1270, center_y), color=INK)
    _arrow(draw, (1270, 532), (1400, 532), color=INK)

    _box(draw, (1400, 415, 1710, 650), WHITE, INK)
    draw.text((1555, 463), "Market", font=_font(34, True), fill=INK, anchor="ma")
    draw.text((1555, 508), "outcomes", font=_font(34, True), fill=INK, anchor="ma")
    draw.text((1555, 552), "survival and welfare", font=_font(24), fill=INK, anchor="ma")

    _box(draw, (390, 900, 1460, 1000), WHITE, INK, radius=16)
    draw.text(
        (925, 940),
        "Separate reduced-form mechanism results from causal mediation claims.",
        font=_font(28, True),
        fill=INK,
        anchor="ma",
    )
    image.save(path, format="PNG")
    path.with_suffix(".svg").write_text(
        """<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="700" viewBox="0 0 1200 700">
<rect width="1200" height="700" fill="#fff"/>
<defs><marker id="a" markerWidth="10" markerHeight="10" refX="9" refY="5" orient="auto"><path d="M0,0 L10,5 L0,10 z" fill="#000"/></marker></defs>
<text x="60" y="62" font-family="Arial" font-size="34" font-weight="700" fill="#000">Mechanism outcomes are estimated separately</text>
<text x="60" y="99" font-family="Arial" font-size="18" fill="#000">The institutional switch changes three post-treatment channels.</text>
<rect x="60" y="280" width="173" height="107" rx="12" fill="#fff" stroke="#000" stroke-width="3"/>
<text x="146" y="325" text-anchor="middle" font-family="Arial" font-size="23" font-weight="700">Expulsion</text>
<text x="146" y="354" text-anchor="middle" font-family="Arial" font-size="23" font-weight="700">switch</text>
<path d="M267 333 L295 333" stroke="#000" stroke-width="3" marker-end="url(#a)"/>
<path d="M295 198 L295 513" stroke="#000" stroke-width="3"/>
<rect x="460" y="153" width="293" height="90" rx="12" fill="#fff" stroke="#000" stroke-width="3"/>
<text x="482" y="188" font-family="Arial" font-size="23" font-weight="700">Fraud</text>
<text x="482" y="218" font-family="Arial" font-size="16">H-C transactions: expected decrease</text>
<rect x="460" y="310" width="293" height="90" rx="12" fill="#fff" stroke="#000" stroke-width="3"/>
<text x="482" y="345" font-family="Arial" font-size="23" font-weight="700">Conversion</text>
<text x="482" y="375" font-family="Arial" font-size="16">honest share: expected decrease</text>
<rect x="460" y="467" width="293" height="90" rx="12" fill="#fff" stroke="#000" stroke-width="3"/>
<text x="482" y="502" font-family="Arial" font-size="23" font-weight="700">Cooperation</text>
<text x="482" y="532" font-family="Arial" font-size="16">H-H trades: expected increase</text>
<path d="M295 198 L460 198" stroke="#000" stroke-width="3" marker-end="url(#a)"/>
<path d="M295 355 L460 355" stroke="#000" stroke-width="3" marker-end="url(#a)"/>
<path d="M295 512 L460 512" stroke="#000" stroke-width="3" marker-end="url(#a)"/>
<path d="M753 198 L847 198 L847 512 L933 512" fill="none" stroke="#000" stroke-width="3" marker-end="url(#a)"/>
<rect x="933" y="275" width="207" height="157" rx="12" fill="#fff" stroke="#000" stroke-width="3"/>
<text x="1036" y="328" text-anchor="middle" font-family="Arial" font-size="23" font-weight="700">Market</text>
<text x="1036" y="358" text-anchor="middle" font-family="Arial" font-size="23" font-weight="700">outcomes</text>
<text x="1036" y="391" text-anchor="middle" font-family="Arial" font-size="16">survival and welfare</text>
<text x="600" y="605" text-anchor="middle" font-family="Arial" font-size="18" font-weight="700">Separate reduced-form mechanism results from causal mediation claims.</text>
</svg>""",
        encoding="utf-8",
    )


def _cluster_ols(
    data: pd.DataFrame,
    outcome: str,
    treatment: str,
    controls: list[str],
    fixed_effects: list[str],
) -> dict[str, float | int | str]:
    columns = [outcome, treatment, "seed", *controls, *fixed_effects]
    data = data.dropna(subset=columns).copy()
    if data.empty:
        return {"estimate": math.nan, "std_error": math.nan, "ci_low": math.nan,
                "ci_high": math.nan, "p_value": math.nan, "n_markets": 0,
                "n_clusters": 0, "status": "no complete rows"}

    parts = [
        pd.Series(1.0, index=data.index, name="intercept"),
        pd.to_numeric(data[treatment], errors="raise").rename("treatment"),
    ]
    for control in controls:
        parts.append(pd.to_numeric(data[control], errors="raise").rename(control))
    for fe in fixed_effects:
        dummies = pd.get_dummies(data[fe], prefix=f"fe_{fe}", drop_first=True, dtype=float)
        parts.append(dummies)
    x = pd.concat(parts, axis=1)
    y = pd.to_numeric(data[outcome], errors="raise")

    xtx_inv = np.linalg.pinv(x.to_numpy().T @ x.to_numpy())
    beta = xtx_inv @ x.to_numpy().T @ y.to_numpy()
    residual = y.to_numpy() - x.to_numpy() @ beta
    score = x.mul(residual, axis=0).groupby(data["seed"]).sum()
    clusters = int(score.shape[0])
    bread = xtx_inv
    covariance = bread @ score.to_numpy().T @ score.to_numpy() @ bread
    if clusters > 1 and len(data) > x.shape[1]:
        covariance *= clusters / (clusters - 1) * (len(data) - 1) / (len(data) - x.shape[1])
    treatment_index = list(x.columns).index("treatment")
    estimate = float(beta[treatment_index])
    standard_error = float(np.sqrt(max(covariance[treatment_index, treatment_index], 0.0)))
    p_value = (
        math.erfc(abs(estimate / standard_error) / math.sqrt(2))
        if standard_error > 0
        else math.nan
    )
    critical = 1.959963984540054
    return {
        "estimate": estimate,
        "std_error": standard_error,
        "ci_low": estimate - critical * standard_error,
        "ci_high": estimate + critical * standard_error,
        "p_value": p_value,
        "n_markets": int(len(data)),
        "n_clusters": clusters,
        "status": "estimated",
    }


def _normalize_transaction_type(value: object) -> str:
    text = str(value).strip().upper().replace(" ", "").replace("-", "")
    aliases = {
        "HH": "HH",
        "HHH": "HH",
        "HONESTHONEST": "HH",
        "CC": "CC",
        "CCC": "CC",
        "CHEATER CHEATER": "CC",
        "CHEATER-CHEATER": "CC",
        "HC": "HC",
        "CH": "HC",
        "HONESTCHEATER": "HC",
        "CHEATERHONEST": "HC",
    }
    return aliases.get(text, text)


def aggregate_event_ledger(events: pd.DataFrame) -> pd.DataFrame:
    required = {"run_id", "seed", "rho", "p", "treatment", "transaction_type"}
    missing = required.difference(events.columns)
    if missing:
        raise ValueError(f"event ledger is missing: {', '.join(sorted(missing))}")
    events = events.copy()
    events["transaction_kind"] = events["transaction_type"].map(_normalize_transaction_type)
    if "social_net_benefit" not in events.columns:
        if {"payer_payoff", "receiver_payoff"}.issubset(events.columns):
            events["social_net_benefit"] = (
                pd.to_numeric(events["payer_payoff"], errors="raise")
                + pd.to_numeric(events["receiver_payoff"], errors="raise")
            )
        else:
            raise ValueError(
                "event ledger needs social_net_benefit or payer_payoff and receiver_payoff"
            )
    events["social_net_benefit"] = pd.to_numeric(
        events["social_net_benefit"], errors="coerce"
    ).fillna(0.0)
    events["_fraud"] = (events["transaction_kind"] == "HC").astype(int)
    events["_cooperation"] = (events["transaction_kind"] == "HH").astype(int)
    if "amount" in events.columns:
        events["_cooperation_volume"] = (
            pd.to_numeric(events["amount"], errors="coerce").fillna(0.0)
            * events["_cooperation"]
        )
    else:
        events["_cooperation_volume"] = events["_cooperation"].astype(float)

    grouped = (
        events.groupby(["run_id", "seed", "rho", "p", "treatment"], as_index=False)
        .agg(
            fraud_count=("_fraud", "sum"),
            cooperation_count=("_cooperation", "sum"),
            cooperation_volume=("_cooperation_volume", "sum"),
            wt=("social_net_benefit", "sum"),
        )
    )
    if "converted_agent" in events.columns:
        conversions = (
            events.loc[events["converted_agent"].notna()]
            .drop_duplicates(["run_id", "converted_agent"])
            .groupby("run_id", as_index=False)
            .size()
            .rename(columns={"size": "conversion_count"})
        )
        grouped = grouped.merge(conversions, on="run_id", how="left")
        grouped["conversion_count"] = grouped["conversion_count"].fillna(0)
    else:
        grouped["conversion_count"] = 0
    if "initial_honest" in events.columns:
        initial = events.groupby("run_id", as_index=False)["initial_honest"].first()
        grouped = grouped.merge(initial, on="run_id", how="left")
    else:
        grouped["initial_honest"] = np.nan
    grouped["conversion_share"] = (
        grouped["conversion_count"] / grouped["initial_honest"]
    )
    for name in (
        "end_wealth_total",
        "survival_steps",
        "bankrupt_count",
        "market_exit_count",
        "active_agent_steps",
    ):
        if name in events.columns:
            first = events.groupby("run_id", as_index=False)[name].max()
            grouped = grouped.merge(first, on="run_id", how="left")
    return grouped


def _write_figures() -> None:
    FIGURES.mkdir(parents=True, exist_ok=True)
    render_mechanism_figure(FIGURES / "figure1_mechanism_design.png")


def write_templates() -> None:
    TABLES.mkdir(parents=True, exist_ok=True)
    mechanism = pd.DataFrame(
        {
            "outcome": PRIMARY_OUTCOMES + SECONDARY_OUTCOMES,
            "expected_sign": [EXPECTED_SIGNS[x] for x in PRIMARY_OUTCOMES + SECONDARY_OUTCOMES],
            "treatment_estimate": np.nan,
            "std_error": np.nan,
            "ci_low": np.nan,
            "ci_high": np.nan,
            "p_value": np.nan,
            "n_markets": np.nan,
            "n_clusters": np.nan,
            "status": "requires run-level or event-level data",
        }
    )
    mechanism.to_csv(TABLES / "table1_mechanism_regression_template.csv", index=False)
    welfare = pd.DataFrame(
        columns=[
            "run_id",
            "seed",
            "treatment",
            "wt",
            "cooperation_count",
            "cooperation_volume",
            "end_wealth_total",
            "survival_steps",
            "bankrupt_count",
            "market_exit_count",
            "wt_resource_net",
        ]
    )
    welfare.to_csv(TABLES / "table2_welfare_outcome_template.csv", index=False)
    rules = pd.DataFrame(
        [
            ("H-H", "2*gHH", "positive", "Mutually beneficial cooperation"),
            ("C-C", "2*gCC", "negative", "Mutually destructive cheating"),
            ("H-C", "gHC_H + gHC_C", "may be zero", "Can be a pure wealth transfer"),
        ],
        columns=["transaction_type", "social_net_benefit", "sign", "interpretation"],
    )
    rules.to_csv(TABLES / "transaction_net_benefit_rules.csv", index=False)
    schema = pd.DataFrame(
        [
            ("run_id", "required", "Market-run identifier"),
            ("seed", "required", "Cluster identifier"),
            ("rho", "required", "Initial cheater share"),
            ("p", "required", "Conversion threshold"),
            ("treatment", "required", "Expulsion switch, 0 or 1"),
            ("fraud_count", "primary outcome", "H-C transaction count"),
            ("conversion_share", "primary outcome", "Converted honest agents divided by initial honest"),
            ("cooperation_count", "primary outcome", "H-H transaction count"),
            ("cooperation_volume", "reported outcome", "Traded value or count-based volume"),
            ("wt", "welfare outcome", "Cumulative social net transaction benefit"),
            ("end_wealth_total", "market outcome", "Wealth at the fixed horizon"),
            ("survival_steps", "market outcome", "Periods before collapse or censoring"),
            ("bankrupt_count", "exit diagnostic", "Wealth exhaustion"),
            ("market_exit_count", "exit diagnostic", "Exit for reasons other than wealth exhaustion"),
        ],
        columns=["column", "role", "definition"],
    )
    schema.to_csv(TABLES / "event_log_schema.csv", index=False)


def analyze_run_data(
    data: pd.DataFrame,
    controls: list[str],
    fixed_effects: list[str],
    survival_cost: float = 0.0,
    resource_cost: bool = False,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    required = {"run_id", "seed", "treatment", *PRIMARY_OUTCOMES}
    missing = required.difference(data.columns)
    if missing:
        raise ValueError(f"run file is missing: {', '.join(sorted(missing))}")
    data = data.copy()
    if survival_cost > 0 and "active_agent_steps" in data.columns:
        data["resource_cost_total"] = survival_cost * data["active_agent_steps"]
        if resource_cost:
            data["wt_resource_net"] = data["wt"] - data["resource_cost_total"]
        else:
            data["wt_resource_net"] = np.nan
    rows = []
    for outcome in PRIMARY_OUTCOMES + SECONDARY_OUTCOMES:
        if outcome not in data.columns:
            continue
        result = _cluster_ols(data, outcome, "treatment", controls, fixed_effects)
        rows.append(
            {
                "outcome": outcome,
                "expected_sign": EXPECTED_SIGNS[outcome],
                **result,
            }
        )
    regressions = pd.DataFrame(rows)
    descriptives = (
        data.groupby("treatment", as_index=False)
        .agg(
            **{
                outcome: (outcome, "mean")
                for outcome in PRIMARY_OUTCOMES + SECONDARY_OUTCOMES
                if outcome in data.columns
            }
        )
    )
    return regressions, descriptives


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    source = parser.add_mutually_exclusive_group()
    source.add_argument("--runs", type=Path, help="run-level outcome CSV")
    source.add_argument("--events", type=Path, help="transaction-event CSV")
    parser.add_argument("--controls", default="", help="comma-separated control columns")
    parser.add_argument("--fixed-effects", default="rho,p", help="comma-separated fixed effects")
    parser.add_argument("--survival-cost", type=float, default=0.0)
    parser.add_argument(
        "--survival-cost-is-resource",
        action="store_true",
        help="subtract survival cost from welfare as a real resource loss",
    )
    args = parser.parse_args()

    _write_figures()
    write_templates()
    if not args.runs and not args.events:
        status = {
            "mode": "templates",
            "message": "Supply --runs or --events to estimate mechanism and welfare outcomes.",
            "survival_cost": args.survival_cost,
            "resource_cost_applied": False,
        }
        print(json.dumps(status, indent=2))
        return

    if args.events:
        data = aggregate_event_ledger(pd.read_csv(args.events))
    else:
        data = pd.read_csv(args.runs)
    controls = [x.strip() for x in args.controls.split(",") if x.strip()]
    fixed_effects = [x.strip() for x in args.fixed_effects.split(",") if x.strip()]
    missing_regressors = [
        column for column in controls + fixed_effects if column not in data.columns
    ]
    if missing_regressors:
        raise ValueError(
            "analysis data is missing control or fixed-effect columns: "
            + ", ".join(missing_regressors)
        )
    cost_applied = bool(
        args.survival_cost > 0
        and args.survival_cost_is_resource
        and "active_agent_steps" in data.columns
    )
    regressions, descriptives = analyze_run_data(
        data,
        controls=controls,
        fixed_effects=fixed_effects,
        survival_cost=args.survival_cost,
        resource_cost=args.survival_cost_is_resource,
    )
    TABLES.mkdir(parents=True, exist_ok=True)
    regressions.to_csv(TABLES / "table1_mechanism_regressions.csv", index=False)
    descriptives.to_csv(TABLES / "table3_outcomes_by_treatment.csv", index=False)
    if "active_agent_steps" in data.columns and args.survival_cost > 0:
        data.to_csv(TABLES / "run_level_analysis_data.csv", index=False)
    summary = {
        "markets": int(len(data)),
        "clusters": int(data["seed"].nunique()),
        "outcomes_estimated": sorted(regressions["outcome"].tolist()),
        "survival_cost": args.survival_cost,
        "resource_cost_applied": cost_applied,
        "controls": controls,
        "fixed_effects": fixed_effects,
        "warnings": (
            []
            if not args.survival_cost_is_resource
            else (
                []
                if cost_applied
                else ["resource cost requested but active_agent_steps is unavailable"]
            )
        ),
        "note": (
            "Mechanism outcomes are reduced-form post-treatment outcomes. "
            "They are not used as controls in the collapse equation."
        ),
    }
    (TABLES / "analysis_results.json").write_text(
        json.dumps(summary, indent=2), encoding="utf-8"
    )
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()

