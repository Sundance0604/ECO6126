#!/usr/bin/env python3
"""Build report/report.docx for the mechanism and welfare section."""

from __future__ import annotations

import argparse
from pathlib import Path

from docx import Document
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor


ROOT = Path(__file__).resolve().parents[1]
FIGURES = ROOT / "figures"
OUTPUT = ROOT / "report" / "report.docx"
DEFAULT_REFERENCE = Path(r"C:\Users\86187\Desktop\section_heterogeneity.docx")

BLACK = RGBColor(0, 0, 0)
WHITE = RGBColor(255, 255, 255)
BLACK_HEX = "000000"


def clear_body(document: Document) -> None:
    body = document._element.body
    for child in list(body):
        if child.tag != qn("w:sectPr"):
            body.remove(child)


def set_run_font(run, size=12, bold=None, italic=None):
    run.font.name = "Times New Roman"
    run._element.get_or_add_rPr().rFonts.set(qn("w:eastAsia"), "Times New Roman")
    run.font.size = Pt(size)
    run.font.color.rgb = BLACK
    if bold is not None:
        run.bold = bold
    if italic is not None:
        run.italic = italic


def set_cell_fill(cell, fill: str) -> None:
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = tc_pr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        tc_pr.append(shd)
    shd.set(qn("w:fill"), fill)
    shd.set(qn("w:val"), "clear")


def set_table_borders(table) -> None:
    tbl_pr = table._tbl.tblPr
    borders = tbl_pr.find(qn("w:tblBorders"))
    if borders is None:
        borders = OxmlElement("w:tblBorders")
        tbl_pr.append(borders)
    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        element = borders.find(qn(f"w:{edge}"))
        if element is None:
            element = OxmlElement(f"w:{edge}")
            borders.append(element)
        element.set(qn("w:val"), "single")
        element.set(qn("w:sz"), "4")
        element.set(qn("w:space"), "0")
        element.set(qn("w:color"), BLACK_HEX)


def set_cell_margins(table, top=70, start=90, bottom=70, end=90) -> None:
    tbl_pr = table._tbl.tblPr
    margins = tbl_pr.find(qn("w:tblCellMar"))
    if margins is None:
        margins = OxmlElement("w:tblCellMar")
        tbl_pr.append(margins)
    for key, value in (("top", top), ("start", start), ("bottom", bottom), ("end", end)):
        node = margins.find(qn(f"w:{key}"))
        if node is None:
            node = OxmlElement(f"w:{key}")
            margins.append(node)
        node.set(qn("w:w"), str(value))
        node.set(qn("w:type"), "dxa")


def set_col_widths(table, widths: list[float]) -> None:
    for row in table.rows:
        for idx, width in enumerate(widths):
            row.cells[idx].width = Inches(width)


def add_title(document: Document) -> None:
    paragraph = document.add_paragraph(style="Title")
    run = paragraph.add_run("7 Mechanism and Welfare Analysis")
    set_run_font(run, size=14, bold=True)


def add_heading(document: Document, text: str) -> None:
    paragraph = document.add_paragraph(style="Heading 2")
    run = paragraph.add_run(text)
    set_run_font(run, size=12, bold=True)
    paragraph.paragraph_format.keep_with_next = True


def add_body(document: Document, text: str) -> None:
    paragraph = document.add_paragraph(style="Normal")
    run = paragraph.add_run(text)
    set_run_font(run, size=12)
    paragraph.paragraph_format.space_after = Pt(6)
    paragraph.paragraph_format.line_spacing = 1.5


def add_body_parts(document: Document, parts) -> None:
    paragraph = document.add_paragraph(style="Normal")
    for text, script, italic in parts:
        run = paragraph.add_run(text)
        set_run_font(run, size=12, italic=italic)
        if script == "sub":
            run.font.subscript = True
        elif script == "sup":
            run.font.superscript = True
    paragraph.paragraph_format.space_after = Pt(6)
    paragraph.paragraph_format.line_spacing = 1.5


def add_formula(document: Document, parts) -> None:
    paragraph = document.add_paragraph(style="Normal")
    paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
    for text, script, italic in parts:
        run = paragraph.add_run(text)
        set_run_font(run, size=12, italic=italic)
        if script == "sub":
            run.font.subscript = True
        elif script == "sup":
            run.font.superscript = True
    paragraph.paragraph_format.space_before = Pt(4)
    paragraph.paragraph_format.space_after = Pt(8)


def add_figure(document: Document, path: Path, caption: str, note: str) -> None:
    add_heading(document, caption)
    paragraph = document.add_paragraph(style="Normal")
    paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
    paragraph.add_run().add_picture(str(path), width=Inches(6.0))
    paragraph.paragraph_format.space_after = Pt(3)
    note_paragraph = document.add_paragraph(style="Normal")
    note_run = note_paragraph.add_run(note)
    set_run_font(note_run, size=9)
    note_paragraph.paragraph_format.line_spacing = 1.0
    note_paragraph.paragraph_format.space_after = Pt(8)


def add_mechanism_table(document: Document) -> None:
    headers = ["Outcome", "Definition", "Expected sign", "Estimate", "Cluster SE", "95% CI"]
    rows = [
        ("Fraud", "H-C transaction count", "Negative", "Pending", "Pending", "Pending"),
        ("Conversion", "Converted honest / initial honest", "Negative", "Pending", "Pending", "Pending"),
        ("Cooperation", "H-H transaction count", "Positive", "Pending", "Pending", "Pending"),
        ("Cooperation volume", "H-H traded value", "Positive", "Pending", "Pending", "Pending"),
    ]
    table = document.add_table(rows=1 + len(rows), cols=len(headers))
    table.style = "Table Grid"
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False
    set_table_borders(table)
    set_cell_margins(table)
    set_col_widths(table, [1.06, 1.85, 0.85, 0.80, 0.75, 0.69])
    for col, label in enumerate(headers):
        cell = table.cell(0, col)
        cell.text = ""
        run = cell.paragraphs[0].add_run(label)
        set_run_font(run, size=8.5, bold=True)
        run.font.color.rgb = WHITE
        cell.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
        cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
        set_cell_fill(cell, BLACK_HEX)
    for row_idx, values in enumerate(rows, start=1):
        for col, value in enumerate(values):
            cell = table.cell(row_idx, col)
            cell.text = ""
            paragraph = cell.paragraphs[0]
            paragraph.alignment = WD_ALIGN_PARAGRAPH.LEFT if col == 1 else WD_ALIGN_PARAGRAPH.CENTER
            paragraph.paragraph_format.space_after = Pt(0)
            paragraph.paragraph_format.line_spacing = 1.0
            run = paragraph.add_run(value)
            set_run_font(run, size=8.5)
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
    note = document.add_paragraph(style="Normal")
    run = note.add_run(
        "Notes: each outcome is a separate regression on the expulsion switch "
        "and predetermined controls. Standard errors are clustered on seed. "
        "The table is populated by the repository script when event-level data "
        "are supplied."
    )
    set_run_font(run, size=9)
    note.paragraph_format.line_spacing = 1.0
    note.paragraph_format.space_after = Pt(8)


def add_welfare_table(document: Document) -> None:
    headers = ["Outcome", "Definition", "Reporting role"]
    rows = [
        ("WT", "Cumulative social net benefit, t = 1 to T", "Primary welfare outcome"),
        ("Cooperative volume", "Sum of H-H traded value", "Cooperation intensity"),
        ("End-period wealth", "Total wealth at the fixed horizon", "Distributional consequence"),
        ("Survival time", "Periods before collapse or horizon", "Market persistence"),
        ("Wealth exhaustion", "Wealth at or below zero", "Financial failure"),
        ("Other market exit", "Exit without wealth exhaustion", "Separate exit channel"),
    ]
    table = document.add_table(rows=1 + len(rows), cols=len(headers))
    table.style = "Table Grid"
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False
    set_table_borders(table)
    set_cell_margins(table)
    set_col_widths(table, [1.20, 2.65, 2.15])
    for col, label in enumerate(headers):
        cell = table.cell(0, col)
        cell.text = ""
        run = cell.paragraphs[0].add_run(label)
        set_run_font(run, size=8.5, bold=True)
        run.font.color.rgb = WHITE
        cell.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
        cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
        set_cell_fill(cell, BLACK_HEX)
    for row_idx, values in enumerate(rows, start=1):
        for col, value in enumerate(values):
            cell = table.cell(row_idx, col)
            cell.text = ""
            paragraph = cell.paragraphs[0]
            paragraph.alignment = WD_ALIGN_PARAGRAPH.LEFT
            paragraph.paragraph_format.space_after = Pt(0)
            paragraph.paragraph_format.line_spacing = 1.0
            run = paragraph.add_run(value)
            set_run_font(run, size=8.5)
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
    note = document.add_paragraph(style="Normal")
    run = note.add_run(
        "Notes: the fixed horizon keeps WT comparable across markets. Survival "
        "time, wealth exhaustion, and other exit are reported separately."
    )
    set_run_font(run, size=9)
    note.paragraph_format.line_spacing = 1.0
    note.paragraph_format.space_after = Pt(8)


def build(reference: Path | None) -> None:
    if reference is not None and reference.exists():
        document = Document(reference)
        clear_body(document)
    else:
        document = Document()
    section = document.sections[0]
    section.page_width = Inches(8.5)
    section.page_height = Inches(11)
    section.top_margin = Inches(1.25)
    section.bottom_margin = Inches(1.25)
    section.left_margin = Inches(1.25)
    section.right_margin = Inches(1.25)
    style = document.styles["Normal"]
    style.font.name = "Times New Roman"
    style.font.size = Pt(12)
    style.font.color.rgb = BLACK

    add_title(document)
    add_body(
        document,
        "This section examines how expulsion changes the composition of market "
        "activity and the social value created by that activity. The mechanism "
        "evidence is organized around fraudulent transactions, honest-to-cheater "
        "conversion, and cooperative transactions. Welfare is aggregated from the "
        "social net benefit of individual transactions over a fixed observation "
        "window. Both are consequences of the institutional switch, not controls "
        "in the collapse equation.",
    )

    add_heading(document, "7.1 Mechanism outcomes")
    add_body_parts(
        document,
        [
            ("Let ", None, False),
            ("D", None, True),
            ("i", "sub", True),
            (
                " denote the expulsion switch for market run ",
                None,
                False,
            ),
            ("i", None, True),
            (
                ", with a value of 1 when expulsion is enabled and 0 when it is "
                "disabled. Let ",
                None,
                False,
            ),
            ("X", None, True),
            ("i", "sub", True),
            (
                " contain predetermined experimental controls and seed-level "
                "blocking variables. The three mechanism equations are estimated "
                "separately.",
                None,
                False,
            ),
        ],
    )
    add_formula(
        document,
        [
            ("Fraud", None, True),
            ("iT", "sub", True),
            (" = ", None, False),
            ("α", None, True),
            ("F", "sub", True),
            (" + ", None, False),
            ("β", None, True),
            ("F", "sub", True),
            ("D", None, True),
            ("i", "sub", True),
            (" + ", None, False),
            ("γ′", None, True),
            ("F", "sub", True),
            ("X", None, True),
            ("i", "sub", True),
            (" + ", None, False),
            ("ε", None, True),
            ("Fi", "sub", True),
        ],
    )
    add_formula(
        document,
        [
            ("Conversion", None, True),
            ("iT", "sub", True),
            (" = ", None, False),
            ("α", None, True),
            ("C", "sub", True),
            (" + ", None, False),
            ("β", None, True),
            ("C", "sub", True),
            ("D", None, True),
            ("i", "sub", True),
            (" + ", None, False),
            ("γ′", None, True),
            ("C", "sub", True),
            ("X", None, True),
            ("i", "sub", True),
            (" + ", None, False),
            ("ε", None, True),
            ("Ci", "sub", True),
        ],
    )
    add_formula(
        document,
        [
            ("Cooperation", None, True),
            ("iT", "sub", True),
            (" = ", None, False),
            ("α", None, True),
            ("K", "sub", True),
            (" + ", None, False),
            ("β", None, True),
            ("K", "sub", True),
            ("D", None, True),
            ("i", "sub", True),
            (" + ", None, False),
            ("γ′", None, True),
            ("K", "sub", True),
            ("X", None, True),
            ("i", "sub", True),
            (" + ", None, False),
            ("ε", None, True),
            ("Ki", "sub", True),
        ],
    )
    add_body(
        document,
        "Fraud is the number of honest-cheater transactions over the observation "
        "window. Conversion is the share of initially honest agents who become "
        "cheaters. Cooperation is the number of honest-honest transactions. When "
        "the ledger contains transaction values, the analysis also reports "
        "cooperation volume, defined as the sum of traded value in honest-honest "
        "transactions.",
    )
    add_body(
        document,
        "The protection-of-cooperation mechanism predicts negative Fraud and "
        "Conversion coefficients and a positive Cooperation coefficient. "
        "Expulsion should reduce fraudulent encounters and the conversion share "
        "while preserving cooperative exchange. The three "
        "coefficients are estimated separately because all outcomes are measured "
        "after treatment. A joint pattern in the expected directions supports the "
        "mechanism narrative, but it is not a causal mediation decomposition.",
    )
    add_figure(
        document,
        FIGURES / "figure1_mechanism_design.png",
        "Figure 7.1 Mechanism outcomes and their separation from collapse",
        "Notes: Fraud, Conversion, and Cooperation are post-treatment outcomes. "
        "They are not used as controls in the collapse or survival equation.",
    )
    add_heading(document, "Table 7.1 Mechanism outcome regressions")
    add_mechanism_table(document)

    add_heading(document, "7.2 Transaction social net benefit")
    add_body(
        document,
        "For a transaction between two agents, let the payer payoff and receiver "
        "payoff be recorded separately. Social net benefit is the sum of those two "
        "payoffs.",
    )
    add_formula(
        document,
        [
            ("S", None, True),
            ("ij", "sub", True),
            (" = ", None, False),
            ("g", None, True),
            ("ij", "sub", True),
            ("i", "sup", True),
            (" + ", None, False),
            ("g", None, True),
            ("ij", "sub", True),
            ("j", "sup", True),
        ],
    )
    add_body(
        document,
        "For honest-honest cooperation, social net benefit is twice the H-H "
        "payoff and is positive. For cheater-cheater exchange, it is twice the "
        "C-C payoff and is negative. For honest-cheater exchange, it is the sum of "
        "the H-C payer and receiver payoffs. The last sum may equal zero when "
        "fraud is a pure wealth transfer, so no positive social value is assigned "
        "by default.",
    )
    add_formula(
        document,
        [
            ("W", None, True),
            ("T", "sub", True),
            (" = Σ", None, False),
            ("t=1", "sub", True),
            ("T", "sup", True),
            (" Σ", None, False),
            ("(i,j)∈A", "sub", True),
            ("t", "sub", True),
            (" S", None, True),
            ("ij", "sub", True),
        ],
    )
    add_body(
        document,
        "The fixed horizon T keeps welfare comparable across markets. If a market "
        "ends before T, the ledger must state whether remaining periods are "
        "censored, truncated, or assigned zero welfare.",
    )
    add_heading(document, "Table 7.2 Welfare and market outcomes")
    add_welfare_table(document)

    add_heading(document, "7.3 Survival cost and wealth exit")
    add_body(
        document,
        "A per-period survival cost c requires an explicit interpretation. If c "
        "represents a real resource used to keep the market operating, "
        "resource-adjusted welfare subtracts c multiplied by participant-periods "
        "from WT. If c is an accounting normalization or a transfer, it is not "
        "subtracted from WT. The analysis reports transaction welfare and "
        "resource-adjusted welfare as distinct outcomes.",
    )
    add_body(
        document,
        "Market exit is separated from wealth exhaustion. Wealth exhaustion occurs "
        "when an agent's balance reaches zero. Other market exit can occur because "
        "of expulsion, a voluntary rule, or another non-bankruptcy mechanism. "
        "Survival time measures how long the market remains active before the "
        "honest population falls below the collapse threshold. These outcomes are "
        "reported in separate columns.",
    )

    add_heading(document, "7.4 Inference and interpretation")
    add_body_parts(
        document,
        [
            ("The main mechanism estimate is the OLS coefficient on ", None, False),
            ("D", None, True),
            ("i", "sub", True),
            (
                " with predetermined controls and market-type fixed effects. "
                "Standard errors are clustered on the random seed so repeated "
                "transactions and repeated rules within a seed are not treated as "
                "independent observations.",
                None,
                False,
            ),
        ],
    )
    add_body(
        document,
        "The mechanism results must not be used to construct a causal claim by "
        "adding Fraud, Conversion, and Cooperation to a regression of collapse or "
        "survival on treatment. Those variables are affected by treatment and may "
        "share unobserved determinants with the outcome. Such a regression "
        "estimates an associational decomposition conditional on post-treatment "
        "variables. A causal mediation claim requires additional assumptions, a "
        "defined intervention on the mediator, and an identification strategy for "
        "the mediator and outcome paths.",
    )
    add_body(
        document,
        "The required substantive pattern is therefore reported as three "
        "reduced-form results. Expulsion protects cooperation if it reduces fraud "
        "and conversion while raising cooperative activity. The welfare ledger "
        "separately shows whether the compositional change produces a higher "
        "cumulative social net benefit. The survival analysis remains the "
        "market-level outcome and is reported alongside, not inside, the mechanism "
        "regressions.",
    )

    add_heading(document, "7.5 Reproducibility and data requirements")
    add_body(
        document,
        "The repository accepts either a run-level outcome file or a transaction "
        "ledger. The run-level file must contain run_id, seed, rho, p, treatment, "
        "fraud_count, conversion_share, cooperation_count, wt, end_wealth_total, "
        "and survival_steps. Optional columns identify cooperative volume, "
        "bankruptcies, other exits, and active participant-periods.",
    )
    add_body(
        document,
        "The event-level file must contain transaction type and transaction social "
        "net benefit, either directly or through payer and receiver payoff columns. "
        "The analysis script aggregates the ledger into market-run outcomes, "
        "estimates the three mechanism regressions, and reports welfare and "
        "survival in separate tables. No mechanism or welfare coefficient is "
        "filled from the aggregate survival file, which does not contain these "
        "variables.",
    )

    document.core_properties.title = "7 Mechanism and Welfare Analysis"
    document.core_properties.subject = (
        "Mechanism outcomes, transaction social benefit, and market survival"
    )
    document.core_properties.author = ""
    document.core_properties.last_modified_by = ""
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    document.save(OUTPUT)
    print(OUTPUT)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--template", type=Path, default=DEFAULT_REFERENCE)
    args = parser.parse_args()
    build(args.template)


if __name__ == "__main__":
    main()

