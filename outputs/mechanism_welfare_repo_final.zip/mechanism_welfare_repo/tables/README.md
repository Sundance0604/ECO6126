# Tables

`table1_mechanism_regression_template.csv` is the reporting template for the
three primary mechanism outcomes and the secondary market outcomes. It contains
expected signs and leaves coefficient cells blank until a run-level or event-level
file is supplied.

`table2_welfare_outcome_template.csv` lists the columns needed to report
fixed-horizon welfare, cooperation volume, end-period wealth, survival, and the
two exit channels.

`transaction_net_benefit_rules.csv` records the social payoff rule for H-H,
C-C, and H-C transactions. `event_log_schema.csv` defines the required and
optional event-ledger fields.

Running the analysis script with complete data writes:

- `table1_mechanism_regressions.csv`
- `table3_outcomes_by_treatment.csv`
- `run_level_analysis_data.csv`
- `analysis_results.json`

